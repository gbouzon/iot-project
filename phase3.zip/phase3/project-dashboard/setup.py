
from setuptools import setup,find_packages

setup(
	name = "Freenove_DHT",
	version = "V1.0.1",
	description = "Read DHT Sensor",
	author = "Freenove",
	url = "http://www.freenove.com",
	license = " ",
	packages = find_packages(),
	scripts = ["Freenove_DHT.py"],
	)
